(function () {
  var N = 40;
  var $ = function (s, r) { return (r || document).querySelector(s); };

  var SENSORS = [
    {
      id: 'ph', name: 'Water quality', part: 'pH probe', unit: 'pH', min: 0, max: 14, dec: 2, base: 7.2, noise: 0.04,
      zones: [[0, 6, 2], [6, 6.5, 1], [6.5, 8.5, 0], [8.5, 9, 1], [9, 14, 2]],
      pills: ['Safe', 'Borderline', 'Polluted'], alert: 'Water is polluted',
      msg: function (v, l) {
        if (v < 6) return 'Polluted: water is too acidic';
        if (v > 9) return 'Polluted: water is too alkaline';
        if (l === 1) return 'Borderline, test the water again';
        return 'Safe range (6.5 to 8.5)';
      }
    },
    {
      id: 'soil', name: 'Soil condition', part: 'Soil moisture', unit: '% moisture', min: 0, max: 100, dec: 0, base: 48, noise: 0.6,
      zones: [[0, 20, 2], [20, 35, 1], [35, 65, 0], [65, 80, 1], [80, 100, 2]],
      pills: ['Healthy', 'Check', 'Critical'], alert: 'Soil condition is critical',
      msg: function (v) {
        if (v < 20) return 'Very dry, the soil needs water';
        if (v < 35) return 'Getting dry';
        if (v <= 65) return 'Healthy moisture level';
        if (v <= 80) return 'Quite wet';
        return 'Waterlogged';
      }
    },
    {
      id: 'temp', name: 'Temperature', part: 'DHT22', unit: '°C', min: 0, max: 80, dec: 1, base: 28, noise: 0.15,
      zones: [[0, 10, 1], [10, 38, 0], [38, 50, 1], [50, 80, 2]],
      pills: ['Normal', 'Warning', 'Danger'], alert: 'Dangerous temperature',
      msg: function (v) {
        if (v < 10) return 'Cold';
        if (v < 38) return 'Normal temperature';
        if (v < 50) return 'Hot';
        return 'Dangerous heat';
      }
    },
    {
      id: 'uv', name: 'UV radiation', part: 'GUVA-S12SD', unit: 'UV index', min: 0, max: 12, dec: 1, base: 2.2, noise: 0.1,
      zones: [[0, 6, 0], [6, 8, 1], [8, 12, 2]],
      pills: ['Low', 'High', 'Extreme'], alert: 'Very high UV detected',
      msg: function (v) {
        if (v < 3) return 'Low UV, no concern';
        if (v < 6) return 'Moderate UV detected';
        if (v < 8) return 'High UV detected';
        return 'Very high UV detected';
      }
    },
    {
      id: 'rf', name: 'Radio waves', part: 'RF detector', unit: '% signal', min: 0, max: 100, dec: 0, base: 12, noise: 2,
      zones: [[0, 40, 0], [40, 70, 1], [70, 100, 2]],
      pills: ['None', 'Detected', 'Strong'], alert: 'Strong radio source detected',
      msg: function (v) {
        if (v < 40) return 'No unusual radio signal';
        if (v < 70) return 'Radio signal detected';
        return 'Strong radio source nearby';
      }
    },
    {
      id: 'fire', name: 'Fire sensor', part: 'IR flame sensor', unit: '% flame', min: 0, max: 100, dec: 0, base: 0, noise: 0.3,
      zones: [[0, 20, 0], [20, 50, 1], [50, 100, 2]],
      pills: ['No fire', 'Heat rising', 'Fire'], alert: 'Fire detected',
      msg: function (v, l) {
        if (l === 2) return 'Fire detected. Raise the alarm';
        if (l === 1) return 'Heat is rising, watch closely';
        return 'No flame, no heat spike';
      }
    }
  ];

  var state = {}, hist = {}, targets = {}, lastLevel = {};
  var running = true;
  var logItems = [];
  var mode = 'demo';
  var client = null;

  SENSORS.forEach(function (s) {
    state[s.id] = s.base;
    targets[s.id] = s.base;
    hist[s.id] = [];
    for (var i = 0; i < N; i++) {
      hist[s.id].push(s.base + (Math.random() - 0.5) * 2 * s.noise * 3);
    }
  });

  /* build tiles */
  var grid = $('#tiles');
  SENSORS.forEach(function (s) {
    var el = document.createElement('article');
    el.className = 'tile';
    el.id = 'tile-' + s.id;
    el.dataset.level = '0';
    var segs = s.zones.map(function (z) {
      return '<span class="z z' + z[2] + '" style="width:' + ((z[1] - z[0]) / (s.max - s.min) * 100) + '%"></span>';
    }).join('');
    el.innerHTML =
      '<header><h2>' + s.name + '</h2><span class="part">' + s.part + '</span></header>' +
      '<div class="reading"><span class="val" data-val>--</span><span class="unit">' + s.unit + '</span><span class="pill" data-pill></span></div>' +
      '<div class="gauge-wrap"><div class="gauge">' + segs + '</div><span class="marker" data-marker></span></div>' +
      '<div class="scale"><span>' + s.min + '</span><span>' + s.max + '</span></div>' +
      '<div class="spark-wrap"><svg viewBox="0 0 200 44" preserveAspectRatio="none" aria-hidden="true"><polygon data-area></polygon><polyline data-line></polyline></svg><span class="dot" data-dot></span></div>' +
      '<p class="msg" data-msg></p>';
    grid.appendChild(el);
  });

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  function zoneLevel(s, v) {
    for (var i = 0; i < s.zones.length; i++) {
      if (v >= s.zones[i][0] && v < s.zones[i][1]) return s.zones[i][2];
    }
    return s.zones[s.zones.length - 1][2];
  }

  function evaluate(s) {
    var lvl = zoneLevel(s, state[s.id]);
    if (s.id === 'fire') {
      var t = state.temp;
      var h = hist.temp;
      var rise = h[N - 1] - h[N - 6];
      if (t >= 55) lvl = 2;
      else if ((t >= 45 || rise >= 5) && lvl < 1) lvl = 1;
    }
    return lvl;
  }

  function tick() {
    SENSORS.forEach(function (s) {
      var v = state[s.id];
      v += (targets[s.id] - v) * 0.3 + (Math.random() - 0.5) * 2 * s.noise;
      v = clamp(v, s.min, s.max);
      state[s.id] = v;
      hist[s.id].push(v);
      hist[s.id].shift();
    });
  }

  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function clock() {
    var d = new Date();
    return pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
  }

  function addLog(text, lvl) {
    logItems.unshift({ time: clock(), text: text, lvl: lvl });
    if (logItems.length > 8) logItems.pop();
    var ul = $('#log');
    ul.innerHTML = '';
    logItems.forEach(function (it) {
      var li = document.createElement('li');
      if (it.lvl >= 0) li.dataset.level = String(it.lvl);
      var t = document.createElement('time'); t.textContent = it.time;
      var b = document.createElement('span'); b.className = 'bullet';
      var x = document.createElement('span'); x.className = 't'; x.textContent = it.text;
      li.appendChild(t); li.appendChild(b); li.appendChild(x);
      ul.appendChild(li);
    });
  }

  function spark(el, s) {
    var h = hist[s.id];
    var lo = Math.min.apply(null, h), hi = Math.max.apply(null, h);
    var span = Math.max(hi - lo, (s.max - s.min) * 0.08);
    var mid = (hi + lo) / 2;
    lo = mid - span / 2;
    var W = 200, H = 44;
    var pts = h.map(function (v, i) {
      var x = i / (N - 1) * W;
      var y = H - ((v - lo) / span) * (H * 0.8) - H * 0.1;
      return [x, y];
    });
    var line = pts.map(function (p) { return p[0].toFixed(1) + ',' + p[1].toFixed(1); }).join(' ');
    $('[data-line]', el).setAttribute('points', line);
    $('[data-area]', el).setAttribute('points', line + ' ' + W + ',' + H + ' 0,' + H);
    var last = pts[pts.length - 1];
    $('[data-dot]', el).style.top = (last[1] / H * 100).toFixed(1) + '%';
  }

  function render() {
    var worst = 0, count = 0, alerts = [];
    SENSORS.forEach(function (s) {
      var v = state[s.id], lvl = evaluate(s), el = $('#tile-' + s.id);
      el.dataset.level = String(lvl);
      $('[data-val]', el).textContent = v.toFixed(s.dec);
      $('[data-pill]', el).textContent = s.pills[lvl];
      $('[data-msg]', el).textContent = s.msg(v, lvl);
      $('[data-marker]', el).style.left = (clamp((v - s.min) / (s.max - s.min), 0, 1) * 100) + '%';
      spark(el, s);
      if (lvl > 0) count++;
      if (lvl > worst) worst = lvl;
      if (lvl === 2) alerts.push(s);
      if (lastLevel[s.id] !== undefined && lastLevel[s.id] !== lvl) {
        addLog(s.name + ': ' + s.pills[lvl] + ' (' + v.toFixed(s.dec) + ' ' + s.unit + ')', lvl);
      }
      lastLevel[s.id] = lvl;
    });
    var banner = $('#banner');
    banner.dataset.level = String(worst);
    $('#bannerState').textContent = ['Normal', 'Attention', 'Alert'][worst];
    var head;
    if (worst === 0) head = 'All sensors normal';
    else if (worst === 1) head = count + (count === 1 ? ' sensor needs attention' : ' sensors need attention');
    else head = alerts[0].alert + (alerts.length > 1 ? ' (+' + (alerts.length - 1) + ' more)' : '');
    $('#bannerHead').textContent = head;
    $('#bannerStamp').textContent = 'Updated ' + clock() + (mode === 'live' ? ' · live from ESP32' : ' · simulated data');
  }

  var SCN = {
    water: { vals: { ph: 4.6 }, text: 'Demo: polluted water started' },
    soil: { vals: { soil: 10 }, text: 'Demo: dry soil started' },
    uv: { vals: { uv: 10 }, text: 'Demo: UV burst started' },
    radio: { vals: { rf: 84 }, text: 'Demo: radio signal started' },
    fire: { vals: { fire: 88, temp: 66 }, text: 'Demo: fire started' }
  };

  document.querySelectorAll('[data-scn]').forEach(function (b) {
    b.addEventListener('click', function () {
      if (mode !== 'demo') { addLog('Switch to Demo mode to use these buttons', -1); return; }
      var key = b.getAttribute('data-scn');
      if (key === 'normal') {
        SENSORS.forEach(function (s) { targets[s.id] = s.base; });
        addLog('Demo: back to normal', -1);
      } else {
        var sc = SCN[key];
        Object.keys(sc.vals).forEach(function (id) { targets[id] = sc.vals[id]; });
        addLog(sc.text, -1);
      }
      if (!running) { tick(); render(); }
    });
  });

  $('#pauseBtn').addEventListener('click', function () {
    running = !running;
    this.textContent = running ? 'Pause' : 'Resume';
    $('#liveText').textContent = running ? 'Live' : 'Paused';
    $('#liveChip').classList.toggle('paused', !running);
  });

  /* ---------- live data from the ESP32 over MQTT ---------- */
  var BROKER_URL = 'wss://broker.hivemq.com:8884/mqtt';

  function setConn(t) { $('#connStatus').textContent = t; }

  function disconnectLive() {
    if (client) {
      try { client.end(true); } catch (e) {}
      client = null;
    }
  }

  function applyReading(d) {
    SENSORS.forEach(function (s) {
      var v = d[s.id];
      if (typeof v === 'number' && isFinite(v)) {
        v = clamp(v, s.min, s.max);
        state[s.id] = v;
        hist[s.id].push(v);
        hist[s.id].shift();
      }
    });
    setConn('Live data received at ' + clock());
    render();
  }

  function connectLive() {
    var topic = $('#topicInput').value.trim().replace(/\/+$/, '');
    if (!topic) { setConn('Enter your topic first, for example ecosentinel/your-name'); return false; }
    if (typeof mqtt === 'undefined') { setConn('The MQTT library did not load. Check your internet connection.'); return false; }
    try { localStorage.setItem('ecoTopic', topic); } catch (e) {}
    disconnectLive();
    setConn('Connecting to the broker...');
    client = mqtt.connect(BROKER_URL, {
      clientId: 'ecodash-' + Math.random().toString(16).slice(2, 10),
      reconnectPeriod: 3000
    });
    client.on('connect', function () {
      setConn('Connected. Waiting for data on ' + topic + '/telemetry');
      client.subscribe(topic + '/telemetry');
    });
    client.on('message', function (t, payload) {
      try { applyReading(JSON.parse(payload.toString())); } catch (e) {}
    });
    client.on('reconnect', function () { setConn('Reconnecting to the broker...'); });
    client.on('offline', function () { setConn('Offline. Check your internet connection.'); });
    client.on('error', function () { setConn('Connection problem. Retrying...'); });
    return true;
  }

  function setMode(m) {
    if (m === 'live') {
      if (!connectLive()) return;
    } else {
      disconnectLive();
      setConn('Demo mode: simulated sensors. Enter your topic and choose Live to see the ESP32 data.');
    }
    mode = m;
    $('#modeDemo').classList.toggle('primary', m === 'demo');
    $('#modeLive').classList.toggle('primary', m === 'live');
    render();
  }

  $('#modeDemo').addEventListener('click', function () { setMode('demo'); });
  $('#modeLive').addEventListener('click', function () { setMode('live'); });
  $('#topicInput').addEventListener('keydown', function (e) {
    if (e.key === 'Enter') setMode('live');
  });

  var urlTopic = null;
  try { urlTopic = new URLSearchParams(location.search).get('topic'); } catch (e) {}
  var savedTopic = null;
  try { savedTopic = localStorage.getItem('ecoTopic'); } catch (e) {}
  $('#topicInput').value = urlTopic || savedTopic || '';

  addLog('Dashboard started, six simulated sensors online', -1);
  render();
  if (urlTopic) { setMode('live'); }
  setInterval(function () {
    if (running && mode === 'demo') { tick(); render(); }
  }, 1000);
})();
